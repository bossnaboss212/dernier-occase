# Ton code principal du bot (copie depuis le canvas)
# Ici tu devras coller le contenu complet de telegram_shop_bot_main.py qu’on a généré.
# (Je n’inclus pas tout le code ici car il est déjà disponible dans ton canvas GitHub)
